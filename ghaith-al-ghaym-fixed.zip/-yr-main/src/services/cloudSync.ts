import { doc, onSnapshot, setDoc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';

export type CloudSyncStatus = 'connected' | 'syncing' | 'offline' | 'error';

const CLOUD_DOC_PATH = {
  collection: 'institution_database',
  id: 'master_state'
};

// دمج السجلات مع احترام العناصر المحذوفة وتفادي مسح مدخلات المعلمات المتزامنة
const mergeArrayByKey = (
  existingList: any[] = [],
  incomingList: any[] = [],
  key: string = 'id',
  deletedSet: Set<string> = new Set()
) => {
  const map = new Map<string, any>();

  for (const item of existingList) {
    if (item && item[key] !== undefined && !deletedSet.has(String(item[key]))) {
      map.set(String(item[key]), item);
    }
  }

  for (const item of incomingList) {
    if (!item || item[key] === undefined) continue;
    const itemKey = String(item[key]);
    if (deletedSet.has(itemKey)) {
      map.delete(itemKey);
      continue;
    }
    const existing = map.get(itemKey);
    if (!existing) {
      map.set(itemKey, item);
    } else {
      const existingTime = existing.updatedAt || existing.recordedAt || existing.evaluatedAt || existing.createdAt || 0;
      const incomingTime = item.updatedAt || item.recordedAt || item.evaluatedAt || item.createdAt || 0;

      const t1 = typeof existingTime === 'string' ? new Date(existingTime).getTime() : Number(existingTime) || 0;
      const t2 = typeof incomingTime === 'string' ? new Date(incomingTime).getTime() : Number(incomingTime) || 0;

      map.set(itemKey, t2 >= t1 ? { ...existing, ...item } : { ...item, ...existing });
    }
  }

  return Array.from(map.values());
};

/**
 * الاشتراك في تحديثات قاعدة البيانات السحابية لحظياً
 */
export const subscribeToCloudDatabase = (
  onData: (data: any) => void,
  onStatusChange?: (status: CloudSyncStatus) => void
) => {
  try {
    const docRef = doc(db, CLOUD_DOC_PATH.collection, CLOUD_DOC_PATH.id);

    const unsubscribe = onSnapshot(
      docRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const cloudData = snapshot.data();
          onData(cloudData);
          if (onStatusChange) onStatusChange('connected');
        } else {
          if (onStatusChange) onStatusChange('connected');
        }
      },
      (error) => {
        console.warn('Firebase sync listener error:', error);
        if (onStatusChange) onStatusChange('offline');
      }
    );

    return unsubscribe;
  } catch (err) {
    console.warn('Failed to subscribe to cloud database:', err);
    if (onStatusChange) onStatusChange('offline');
    return () => {};
  }
};

/**
 * رفع الحالة وتحديث السجلات في Firestore بأمان ودون محو سجلات الآخرين أو إعادة السجلات المحذوفة
 */
export const pushStateToCloud = async (statePayload: any): Promise<void> => {
  try {
    const docRef = doc(db, CLOUD_DOC_PATH.collection, CLOUD_DOC_PATH.id);

    const currentSnap = await getDoc(docRef);
    let finalPayload = { ...statePayload };

    if (currentSnap.exists()) {
      const remoteData = currentSnap.data();
      const mergedDeletedIds = Array.from(
        new Set([...(remoteData.deletedIds || []), ...(statePayload.deletedIds || [])])
      );
      const deletedSet = new Set<string>(mergedDeletedIds.map(String));

      finalPayload = {
        ...remoteData,
        ...statePayload,
        deletedIds: mergedDeletedIds,
        users: mergeArrayByKey(remoteData.users, statePayload.users, 'id', deletedSet),
        tracks: mergeArrayByKey(remoteData.tracks, statePayload.tracks, 'id', deletedSet),
        circles: mergeArrayByKey(remoteData.circles, statePayload.circles, 'id', deletedSet),
        students: mergeArrayByKey(remoteData.students, statePayload.students, 'id', deletedSet),
        monthlyPlans: mergeArrayByKey(remoteData.monthlyPlans, statePayload.monthlyPlans, 'id', deletedSet),
        atqiniAssignments: mergeArrayByKey(remoteData.atqiniAssignments, statePayload.atqiniAssignments, 'id', deletedSet),
        challenges: mergeArrayByKey(remoteData.challenges, statePayload.challenges, 'id', deletedSet),
        monthlyExams: mergeArrayByKey(remoteData.monthlyExams, statePayload.monthlyExams, 'id', deletedSet),
        dailyRecords: mergeArrayByKey(remoteData.dailyRecords, statePayload.dailyRecords, 'id', deletedSet),
        attendanceRecords: mergeArrayByKey(remoteData.attendanceRecords, statePayload.attendanceRecords, 'id', deletedSet),
        studentPlans: mergeArrayByKey(remoteData.studentPlans, statePayload.studentPlans, 'id', deletedSet),
        studentExamResults: mergeArrayByKey(remoteData.studentExamResults, statePayload.studentExamResults, 'id', deletedSet),
        studentAtqiniSubmissions: mergeArrayByKey(remoteData.studentAtqiniSubmissions, statePayload.studentAtqiniSubmissions, 'id', deletedSet),
        studentChallengeSubmissions: mergeArrayByKey(remoteData.studentChallengeSubmissions, statePayload.studentChallengeSubmissions, 'id', deletedSet),
        studentSubscriptions: mergeArrayByKey(remoteData.studentSubscriptions, statePayload.studentSubscriptions, 'id', deletedSet),
        gradingConfigs: mergeArrayByKey(remoteData.gradingConfigs, statePayload.gradingConfigs, 'trackId', deletedSet),
        settings: { ...(remoteData.settings || {}), ...(statePayload.settings || {}) },
        lastSyncedAt: new Date().toISOString()
      };
    }

    await setDoc(docRef, finalPayload, { merge: true });
  } catch (error) {
    console.warn('Failed to push state to Firestore cloud:', error);
    throw error;
  }
};
